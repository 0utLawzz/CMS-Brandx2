# Architecture Documentation

## Core Components

The **OutLawZ D-Sheet** relies on an extremely lean, three-file architecture pattern designed for maximum portability.

### 1. Structure Layer (`index.html`)
- Provides the semantic HTML5 skeleton.
- Defines the tab layouts, statistical tile containers, and the search input interfaces.
- Contains inline scripts to prevent theme-flashing on load by preemptively reading `localStorage`.

### 2. Styling Layer (`styles.css`)
- Uses CSS Variables (`var(--color-primary)`) to define design tokens.
- Implements two color palettes linked to the `data-theme` attribute on the `<html>` tag.
- Employs modern CSS Grid and Flexbox for responsive scaling on mobile and desktop devices.

### 3. Logic Layer (`app.js`)
- **Data Fetching:** Utilizes the native `fetch()` API to download the CSV payload from Google's servers.
- **Parsing:** Implements a custom CSV parsing algorithm that handles quoted strings and comma delimiters safely without relying on third-party libraries like `PapaParse`.
- **State Management:** Holds the parsed data in a local JavaScript Array object.
- **DOM Manipulation:** Dynamically constructs HTML table rows (`<tr>` and `<td>`) via template literals based on search input triggers.

## Data Flow Diagram

```mermaid
graph TD
    User([User]) -->|Opens App| UI(index.html)
    UI --> Script(app.js)
    Script -->|Fetch CSV| GS[Google Sheets Server]
    GS -->|Return Data| Script
    Script -->|Parse to JSON| State[In-Memory Array]
    State -->|Render Initial Stats| UI
    
    User -->|Types in Search| Script
    Script -->|Filter| State
    State -->|Render Updates| UI
```

---

## 👨‍💻 Credits

**By OutLawZ™**

Website: https://www.brandex.pk

Need custom automation, AI tools, workflow systems, dashboards, integrations, scraping tools, content automation, or business process automation?

Contact:

📧 Email: net2tara@gmail.com
🌐 Website: https://www.brandex.pk
📘 Facebook: Coming Soon
📸 Instagram: Coming Soon
▶️ YouTube: Coming Soon

---
Made with ❤️ by OutLawZ™
