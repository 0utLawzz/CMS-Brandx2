# Features

## Main Features

- **Master Register View**: Complete tabular view of all rows within the target Google Sheet, fully formatted and color-coded based on application status.
- **Search and Filter**: Instantly filter thousands of rows. The custom vanilla JS search algorithm operates on an in-memory array, meaning searches resolve in milliseconds without network latency.
- **Statistical Summaries**: Extracts key metrics (Total Records, Accepted, In Progress, TM-11s Filed) dynamically on load, ensuring the dashboard metrics are always perfectly synchronized with the underlying data.

## UI/UX Features

- **Persistent Theming**: Includes a custom 'Bloom' (Light) and 'Mist' (Dark) theme architecture. User preferences are saved to `localStorage` and applied immediately on page load to prevent blinding flashes.
- **Aria-Accessible Tabs**: Custom vanilla JavaScript tab switching utilizing proper ARIA roles (`role="tab"`, `aria-selected="true"`) for screen reader compatibility.
- **Loading State Indicators**: Clear visual feedback via loading chips and skeletons while the CSV is being downloaded and parsed.

## Development Features

- **No-Build Architecture**: Can be edited directly via a standard text editor. No Webpack, Vite, or Babel compilation required.
- **Custom CSV Parser**: Avoids the `PapaParse` library by implementing a regex-based robust CSV parser capable of handling internal commas within quoted spreadsheet cells.

---

## 👨‍💻 Credits

**By OutLawZ™**

Website: https://www.brandex.pk

Need custom automation, AI tools, workflow systems, dashboards, integrations, scraping tools, content automation, or business process automation?

Contact:

📧 Email: net2tara@gmail.com
🌐 Website: https://www.brandex.pk
📘 Facebook: Coming Soon
📸 Instagram: Coming Soon
▶️ YouTube: Coming Soon

---
Made with ❤️ by OutLawZ™
