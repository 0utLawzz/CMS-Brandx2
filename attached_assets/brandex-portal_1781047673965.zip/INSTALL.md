# Installation Guide

## Requirements

- A modern web browser (Google Chrome, Mozilla Firefox, Safari, Edge).
- Internet connection (required to fetch the live Google Sheet data).

## Setup & Installation

Since the **OutLawZ D-Sheet** is a purely static, dependency-free application, installation is incredibly simple.

1. **Clone/Download the Repository**
   Ensure you have the `D-Sheet` directory downloaded to your local machine.

2. **Open the App Locally**
   - **Method A (Direct):** Simply double-click the `index.html` file in your file explorer. It will open in your default browser and function immediately.
   - **Method B (Local Server):** If you are actively developing, it is recommended to serve the folder over HTTP. If you use VS Code, install the `Live Server` extension and click "Go Live" at the bottom right.

## Deployment Guide

Because there is no backend, you can host this directory on almost any static hosting provider.

### GitHub Pages (Free)
1. Push this repository to GitHub.
2. Go to the repository **Settings** > **Pages**.
3. Under **Build and deployment**, select **Deploy from a branch**.
4. Choose your main branch and the `/ (root)` folder. Save.
5. Your dashboard will be live at `https://yourusername.github.io/your-repo-name/`.

### Hostinger / Standard cPanel
1. Open your Hostinger hPanel File Manager.
2. Navigate to your `public_html` directory (or a subdomain folder).
3. Upload `index.html`, `app.js`, `styles.css`, and `logo.png`.
4. Visit your domain. No `.htaccess` routing is required.

## Configuration

To connect the dashboard to your own Google Sheet:

1. Open `app.js` in a text editor.
2. Locate the fetch URL at the top of the file.
3. Replace it with your Google Sheets "Publish to Web" CSV link.

---

## 👨‍💻 Credits

**By OutLawZ™**

Website: https://www.brandex.pk

Need custom automation, AI tools, workflow systems, dashboards, integrations, scraping tools, content automation, or business process automation?

Contact:

📧 Email: net2tara@gmail.com
🌐 Website: https://www.brandex.pk
📘 Facebook: Coming Soon
📸 Instagram: Coming Soon
▶️ YouTube: Coming Soon

---
Made with ❤️ by OutLawZ™
