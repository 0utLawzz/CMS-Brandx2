# 🎬 OutLawZ D-Sheet Dashboard

---

# Description

The **OutLawZ D-Sheet** is a lightweight, frontend-only data dashboard designed for Brandex Law Associates. It functions as a public Trademark Portal, allowing users to search and view trademark application records in real-time. Built entirely with vanilla JavaScript, HTML, and CSS, it securely pulls live data from a public Google Sheet exported as a CSV, completely eliminating the need for backend servers or complex API key management.

---

# 🚀 Features

- **Key-less Google Sheets Integration:** Fetches live master register data directly via Google Sheets CSV export URLs.
- **Instant Search:** Provides real-time filtering of trademark applications by number or mark name.
- **Dual View Modes:** Offers a focused search interface alongside a full tabular master register view.
- **Theme Toggling:** Built-in dark and light modes ('bloom' and 'mist') with local storage persistence.
- **Zero Dependencies:** Pure vanilla HTML/CSS/JS implementation. No npm, build steps, or frameworks required.
- **Static Hosting Ready:** Can be hosted for free on GitHub Pages, Vercel, or Hostinger Shared Hosting.

---

# 🛠️ Tech Stack

| Layer | Technology |
| --- | --- |
| **Frontend Language** | HTML5, Vanilla JavaScript |
| **Styling** | Custom Vanilla CSS (`styles.css`) |
| **Data Source** | Google Sheets (Published to Web CSV) |

---

# 📂 Project Structure

```text
D-Sheet/
├── index.html              # Main application entry point and markup
├── app.js                  # Data fetching, parsing, and DOM manipulation logic
├── styles.css              # Custom styling, themes, and layout
├── logo.png                # Brandex Law Associates logo asset
└── README.md               # Documentation
```

---

# 📄 Important Files

| File | Purpose |
| --- | --- |
| `app.js` | Contains the core logic for fetching the remote CSV, parsing the data locally, and rendering the DOM dynamically. |
| `index.html` | The Single Page Application shell, containing the tab structures and semantic markup. |

---

# 🏗️ Architecture Diagram

```mermaid
graph TD
    A[Browser / index.html] --> B[app.js]
    B -->|HTTP GET Request| C[Google Sheets Published CSV URL]
    C -->|Returns CSV Text| B
    B -->|Parses Data| D[In-Memory Array]
    D -->|Renders| E[DOM Table & Search Results]
    E --> F[User Interaction / Filtering]
    F -->|Updates| E
```

---

# 🔄 Processing / Data Flow

```mermaid
flowchart LR
    Start --> FetchCSV
    FetchCSV --> ParseCSV
    ParseCSV --> BuildDashboard
    BuildDashboard --> AwaitUserSearch
    AwaitUserSearch --> FilterData
    FilterData --> RenderResults
```

---

# 📥 Inputs

- **Google Sheets URL:** A publicly published CSV link embedded directly inside `app.js`.
- **User Queries:** Text input for filtering rows based on application numbers or mark names.

---

# 📤 Outputs

- **Visual Dashboard:** Dynamic DOM updates showing statistics (Total, Accepted, In Progress) and filtered tables.

---

# 🏎️ Quick Start

Because this project has zero dependencies, getting started is instantaneous:

1. Clone or download the repository.
2. Open `index.html` directly in your web browser (e.g., double-click it, or use a local server like VS Code Live Server for hot-reloading).

---

# ⚙️ Configuration

To point the dashboard to a different dataset:
1. Open your target Google Sheet.
2. Click **File > Share > Publish to web**.
3. Select the target sheet and choose **Comma-separated values (.csv)**.
4. Copy the generated URL.
5. Open `app.js` and replace the target URL variable with your new link.

---

# 🎯 Use Cases

- **Public Portals:** Providing clients or the public read-only access to specific spreadsheet data without granting them Google Drive access.
- **Internal Dashboards:** Creating rapid, styled UI wrappers around raw spreadsheets for internal team tracking.

---

# 🔒 Security Notes

- **Public Data:** The Google Sheet driving this dashboard must be published to the web. Do not include sensitive or strictly confidential information in the source spreadsheet, as the URL is accessible to anyone inspecting the network traffic.

---

# 🚧 Roadmap

- Implement pagination for extremely large datasets (10,000+ rows) to improve rendering performance.
- Add column sorting capabilities.
- Implement a CSV download button for filtered results.

---

# 📝 License

MIT License

---

## 👨‍💻 Credits

**By OutLawZ™**

Website: https://www.brandex.pk

Need custom automation, AI tools, workflow systems, dashboards, integrations, scraping tools, content automation, or business process automation?

Contact:

📧 Email: net2tara@gmail.com
🌐 Website: https://www.brandex.pk
📘 Facebook: Coming Soon
📸 Instagram: Coming Soon
▶️ YouTube: Coming Soon

---
Made with ❤️ by OutLawZ™
